%% 1.labaratorijas darbs
%% Merijumu datu apstrade
%% Darba merki
% * Iemacities apstradat merijumu datus
% * Iemacities veidot atskaites
%   Izmantot report generator
% * Iemacities nolasit datus no grafika
%% Dots sekojosais grafiks
%
% <<../1.png>>
%
A = imread('2.png');
figure(1), image ([-90,90],[1,0],A)
set (gca, 'YDir','normal')
hold on
x =[
  -88.6566
  -83.3576
  -76.8357
  -67.8682
  -58.0854
  -47.4873
  -37.7045
  -28.7370
  -23.0303
  -12.0247
   -1.8343
    5.5028
   12.8399
   22.6227
   28.3293
   34.4436
   43.0035
   49.1178
   55.6397
   61.7539];
y = [
    0.3960
    0.4435
    0.5059
    0.5802
    0.6635
    0.7437
    0.8210
    0.8775
    0.9131
    0.9636
    0.9815
    0.9785
    0.9636
    0.9191
    0.8834
    0.8418
    0.7883
    0.7378
    0.6902
    0.6367];
plot(x,y,'go-');

C = polyfit(x,y,6);
xx = min(x):0.01:max(x);
yy = polyval(C,xx);
hold off
plot(x,y,'o-', xx, yy);
xlabel('Angle');
ylabel('Relative intensity');
%% Polinoma koeficenti
C
%% Secinajumi:
% * mes uzninajam polinoma koeficenti no mana grafika